# Resumes Folder
This folder is used to store resume files for the CIS615 course.
✅ Uploaded file: `Marcela_Redondo_Resume_2025.pdf`  
This resume is intended for course assignment purposes.
